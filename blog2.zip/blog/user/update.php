<a href="index.php">Back</a>
<form action="" method="POST">
    Email : <input type="email" name="email"/> <br/>
    Password : <input type="password" name="password"/><br/>
    New Password : <input type="password" name="newPassword"/> <br/>
    Confirm New Password: <input type="password" name="confirmPassword"/> <br/>
    <input type="submit" name="updatePassword" value="Update Password"/>
</form>
