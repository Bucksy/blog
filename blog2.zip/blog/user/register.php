<a href="index.php">Back</a>
<form action="" method="POST">
    Username:  
    <input type="text" name="name" id="name" value=""/><br/>
    Email:  
    <input type="text" name="email" id="email" value=""/><br/>
    Password:
    <input type="password" name="password" id="password" value=""/><br/>
    Confirm Password: 
    <input type="password" name="confirmPassword" id="confirmPassword" value=""/><br/>
    
    <input type="submit" name="register" id="registerButton" value="Register"/>
</form>
