<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $user = User::registerUser($_POST['name'], $_POST['email'], $_POST['password'], $_POST['confirmPassword']);
    if (is_array($user)) {
        foreach ($user as $value) {
            echo $value . '<br/>';
        }
    }else {
        //exit(var_dump($user));
        //header('Location : index.php');
        echo $user->name . ' is successfully registered';
        //header('Location: login.php');
    }
}
