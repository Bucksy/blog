<?php
//echo '<pre>' . print_r($_POST, true) . '</pre>';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submitLogin'])) {
    if (isset($_SESSION['logged'])) {
        header('Location: index.php?page=posts&action=get');
    }
    $user = User::loginUser($_POST['email'], $_POST['password']);
    if (is_array($user)) {
        foreach ($user as $value) {
            echo $value . '<br/>';
        }
    }
    //echo $user->name;
}
?>
<a href="index.php?page=user&action=update">Update Password?</a>