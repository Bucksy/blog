<?php
//poneje pravim zaqvka kum tozi fail, a ne ot dispatchera zatova shte ni trea session_start();

session_start();
include '../lib/Post.php';
if ($_SESSION['logged'] == TRUE) {
    //echo 'Session';
    // echo $_SESSION['user_id'];
    //$post = Post::deletePosts($_SESSION['user_id']);
    
    $post = Post::getPost($_GET['id']);
 
    if($post->deletePost()){
        $posts = Post::getPosts($_SESSION['user_id']);
       ?>
         <table border="1">
            <tr>
                <td>ID</td>
                <td>Title</td>
                <td>Description</td>
                <td>Created Date</td>
                <td colspan="2">Actions</td>
            </tr>
            <?php
//            foreach ($posts as $post) {
//                echo '<tr>
//                        <td>' . $post->id . '</td>
//                        <td>' . $post->description . '</td>
//                        <td>' . $post->title . '</td>
//                        <td>' . $post->created . '</td>
//                        <td><a href="index.php?page=posts&action=update&id=' . $post->id . '">Update</a></td>
//                        
//                        <td><button class="delete" id="' . $post->id . '">Delete</button></td>
//                </tr>';
//            }
                    foreach ($posts as $post) {
            echo '<tr id=tr_' . $post->id . '>
                        <td>' . $post->id . '</td>
                        <td>' .
            '<span class="default-post">' . $post->title . '</span>' .
            '<input type="text" class="edit-post input-title" value="' . $post->title . '"/>
                        </td> 
                        <td>' .
            '<span class="default-post">' . $post->description . '</span>' .
            '<input type="text" class="edit-post input-description" value="' . $post->description . '"/>
                        </td>    
                        <td>' . $post->created . '</td>
                        <td>
                            <button class="update" id=update_' . $post->id . '>Update</button>
                            <button data-id="' . $post->id . '" type="submit" class="save edit-post">Save</button>
                        </td>
                        
                        <td>
                            <button class="delete" data-id=' . $post->id . '>Delete</button>
                            <button class="cancel edit-post">Cancel</button>
                        </td>
            </tr>';
        }
        ?>
        </table>
        <?php
        //header('Location: index.php?page=posts&action=get'); //response
    }else{
       echo 'DB Error';
    }
     //exit(var_dump($post));
    //header('Location: posts.php');
}else {
    header('Location: index.php?page=user&action=login');
}

