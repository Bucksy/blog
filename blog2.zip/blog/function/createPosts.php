<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //$_SERVER['test'] = 'test123';
    //exit(var_dump($_SESSION));
    $result = Post::createPost($_POST['title'], $_POST['description']); //object
    if (is_array($result)) {
        foreach ($result as $value) {
            echo $value;
        }
    } else {
        header('Location: index.php?page=posts&action=get');
    }
}
