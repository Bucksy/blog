<a href="index.php?page=posts&action=create">Create Post</a>
<?php
// exit(var_dump($_SESSION));
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    $posts = Post::getPosts($_SESSION['user_id']);
    // echo $_SESSION['user_id'];//10
    // echo '<pre>' . print_r($user, true) . '</pre>';
    ?>
    <div id="new_table">
        <button>Sample Test</button>
        <table border="1px">
            <tr>
                <td>ID</td>
                <td>Title</td>
                <td>Description</td>
                <td>Created Date</td>
                <td colspan="2">Actions</td>
            </tr>
            <?php
            foreach ($posts as $post) {
                echo '<tr id=tr_' . $post->id . '>
                        <td>' . $post->id . '</td>
                        <td>' .
                            '<span class="default-title">' . $post->title . '</span>' .
                            '<input type="text" class="edit-post input-title" value="' . $post->title . '"/>
                        </td> 
                        <td>' .
                            '<span class="default-description">' . $post->description . '</span>' .
                            '<input type="text" class="edit-post input-description" value="' . $post->description . '"/>
                        </td>    
                        <td>' . $post->created . '</td>
                        <td>
                            <button class="update" id=update_' . $post->id . '>Update</button>
                            <button data-id="' . $post->id .'" type="submit" class="save edit-post">Save</button>
                        </td>
                        
                        <td>
                            <button class="delete" data-id='. $post->id .'>Delete</button>
                            <button class="cancel edit-post">Cancel</button>
                        </td>
            </tr>';
            }
        }
        ?>
    </table>
</div>

<script type="text/javascript" src="./js/jquery-1.11.2.min.js"></script>

<script>
    $(document).ready(function () {
        //$('.delete').click(ajaxDelete);
        $('body').on('click', '.delete', function () {
            ajaxDelete($(this));//A function to execute when the event is triggered
        });

        $('body').on('click', '.update', function () {
            updatePost($(this));
        });

        $('#new_table .save').on('click', function(){
            ajaxSave($(this));
        });
        
        $('#new_table .cancel').on('click', function(){
           alert('1');
        });
        
        function ajaxDelete(row) {

           // var updateId = row.attr('id');
            //var res = updateId.split("_");//array update , 155
            var id = row.data('id');

            $.ajax({
                url: 'function/ajaxDeletePost.php?id='+id,
                method: 'GET',
                statusCode: {
                    404: function() {
                     alert( "page not found" );
                    }
                } 
            }).done(function (data) {
                //alert(data);
                $('#new_table').html(data);
                 alert('The post was deleted!');
            }).fail(function (textStatus) { // fake JS object
                console.log(textStatus);
                alert("Failed : " + textStatus); // error
            })
        }

        function updatePost(row) {
            var res = row.attr('id'); // get the id of row
            var id = res.split("_");
            //var defaultPost = $('.default-post').placeholder;
            $('#tr_' + id[1] + ' .edit-post').show();
            $('#tr_' + id[1] + ' .default-title').hide();
            $('#tr_' + id[1] + ' .default-description').hide();
            $('#tr_' + id[1] + ' .save').show();//save button 
            $('#tr_' + id[1] + ' .cancel').show();//cancel button 
            $('#tr_' + id[1] + ' .update').hide();//hide button 
            $('#tr_' + id[1] + ' .delete').hide();//hide button
        }

        function ajaxSave(row) {
            
           // var updateId = row.attr('id');
            //var res = updateId.split("_");//array update , 155
            var id = row.data('id');
            var title = row.parent().parent().find('.input-title');
            var description = row.parent().parent().find('.input-description');
            var newTitle = row.parent().parent().find('.default-title');
            var newDescription = row.parent().parent().find('.default-description');
            
             //console.log(newTitle);
            // title.hide();
            // description.hide();
           // alert($(title).val());
            //console.log(newPost);
            
            $.ajax({
                //alert(title.val());
                url: 'function/ajaxUpdatePost.php?id='+id,
                method: 'PUT',
                data: { //jquery object we send
                      title: title.val(),
                      description: description.val()
                      },
                dataType: 'json',
                statusCode: {
                    404: function() {
                     alert( "page not found" );
                    }
                }
            }).done(function(data) {
               //$('.edit-post').html(data);
               console.log(data);//response Object 
              ///console.log(typeof(data));
               title.hide();
               description.hide();
                //alert(newTitle);
               //alert((data[0].title)); //object input 
              //var parse =  $.parseJSON(data); / /we dont'
             //console.log(parse);
               newTitle.html(data[0].title).show(); //object input 
               newDescription.html(data[0].description).show(); //object input 
               
            }).fail(function(textStatus) {
                console.log(textStatus);
            })
        }
    });
</script>
