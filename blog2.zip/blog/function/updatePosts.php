<?php
session_start();
include '../lib/Post.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updatePost'])) {
    $postId = $_GET['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];

    $post = Post::getPost($postId); //1
    $updatedPost = $post->updatePost($title, $description);
    
   // header('Location: index.php?page=posts&action=get');
}else if($_SERVER['REQUEST_METHOD'] === 'GET'){
    $postId = $_GET['id'];
    $post = Post::getPost($postId);
}
