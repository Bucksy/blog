<?php

parse_str(file_get_contents("php://input"), $post_vars); // tui kato pozlvame PUT - za prashtane na dannite -> na nas shte ni trqbva POST
header('Content-type: application/json');

$ret[] = array(
    'title' => $post_vars['title'],
    'description' => $post_vars['description']
);

//echo '<pre>' . print_r($ret[0]['description'], true) . '</pre>';
echo json_encode($ret);


