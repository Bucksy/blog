<?php
if ($_SESSION['logged'] == TRUE) {
    //echo 'Session';
    // echo $_SESSION['user_id'];
    //$post = Post::deletePosts($_SESSION['user_id']);
    $post = Post::getPost($_GET['id']);
    //$posts = Post::getPosts($_SESSION['user_id']);
    //exit(var_dump($post));
    if($post->deletePost()){//delete the row and then show them 
         $posts = Post::getPosts($_SESSION['user_id']);
       ?>
         <!--this is our response to ajax--> 
         <table>
            <tr>
                <td>ID</td>
                <td>Title</td>
                <td>Description</td>
                <td>Created Date</td>
                <td colspan="2">Actions</td>
            </tr>
            <?php
            foreach ($posts as $post) {
                echo '<tr>
                        <td>' . $post->id . '</td>
                        <td>' . $post->description . '</td>
                        <td>' . $post->title . '</td>
                        <td>' . $post->created . '</td>
                        <td><a href="index.php?page=posts&action=update&id=' . $post->id . '">Update</a></td>
                        <td><button class="delete" id="' . $post->id . '">Delete</button></td>
                </tr>';
            }
            ?>
        </table>
        <?php
        //header('Location: index.php?page=posts&action=get'); //response
    }else{
       echo 'DB Error';
    }
    //exit(var_dump($post));
    //header('Location: posts.php');
}else {
    header('Location: index.php?page=user&action=login');
}
