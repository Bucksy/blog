<?php
  $userLogout = User::logoutUser($_SESSION['user_id']);
?>