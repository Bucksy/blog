<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['updatePassword'])) {
    $updated = User::updatePassword($_POST['email'], $_POST['password'], $_POST['newPassword'], $_POST['confirmPassword']);
    if (is_array($updated)) {
        foreach ($updated as $value) {
            echo $value . '<br/>';
        }
    } else {
        echo 'The user with email : ' . $updated->email . 'has changed his/her password';
    }
}
?>
