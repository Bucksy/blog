<?php session_start(); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title><?= $title; ?></title>
        <script src="js/jquery-1.11.2.min.js" type="text/javascript"></script>
        <script src="js/register.js" type="text/javascript"></script>
        <link rel="stylesheet" type="text/css" href="css/styles.css"/>
    </head>
    <body>
    
      