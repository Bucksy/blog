<form action="index.php?page=posts&action=<?php echo isset($post) ? 'update&id='. $post->id : 'create'?>" method="POST">
    <table>
        <tr>
            <td>Title: </td>
            <td><input type="text" name="title" id="title" value="<?php echo isset($post) ? $post->title : '' ?>"/></td>
        </tr>
        <tr>
            <td>Description: </td>
            <td><input type="text" name="description" id="decription" value="<?php echo isset($post) ? $post->description : '' ?>"/></td>
        </tr>
        <tr><td><input type="submit" name="<?php echo isset($post) ? 'updatePost' : 'createPost'?>" value="<?php echo isset($post) ? 'Update' : 'Create'?>"/></td></tr>
    </table>
</form>
