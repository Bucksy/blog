<?php include './posts/form.php';?>
