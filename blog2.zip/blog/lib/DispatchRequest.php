<?php
class DispatchRequest {
    private $defaultAction = 'Login';
    private $defaultPage = 'User';
    private static $viewNotRequiredList = array(0=>'delete', 1=>'get');

    public static function proccessRequest($page, $action, $function) {
            if (isset($action)) {
               $includeFile = "$page/$action"; //posts/create.php - views 
               $f = $function.'/'.$action.ucfirst($page);// function/createPosts.php - include this file (function)
            }else{
                $includeFile = "$page/$this->defaultAction"; 
                $f = $function.'/'.$this->defaultAction.ucfirst($page); // function/createPosts.php
            }
//            if (!in_array($action, self::$viewNotRequiredList)) {
//                include "$includeFile.php";
//            }
//            include "$f.php";// function/createPosts.php
            include "$f.php";
            if(!in_array($action, self::$viewNotRequiredList)) { //only those actions who are not in array viewNotRequired 
               include "$includeFile.php";
        }
       // include "$f.php";
    }
 }
