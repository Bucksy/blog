<?php

class Post {
    
    public $id;
    public $title,
           $description,
           $created,
           $userId;
    
    //Get Post - Get the data from database 
    public static function getPost($idPost){
         
       // exit(var_dump($_SESSION['user_id']));
        $connection = new mysqli('localhost', 'root', '');
        //check db connection
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed",mysqli_connect_error());
            exit;
        }

        if (empty($idPost)) {
            echo 'Please try again';
            return;
        }
        
        $idPost = (int)$idPost;
        $db = mysqli_select_db( $connection, 'blog') or die('Error in database');
        
        $query = mysqli_query($connection, 'SELECT * FROM posts WHERE id = '.$idPost);
        $row = $query->fetch_assoc();
        
         if ($row['userId'] != $_SESSION['user_id']) {
            header('Location: index.php?page=posts&action=get');
         }
         
        $post = new Post();
        $post->id = $row['id'];
        $post->title = $row['title'];
        $post->description = $row['description'];
        $post->created = $row['created'];
        $post->userId = $row['userId'];
        
        return $post;
        
    }
    
    public function updatePost($title, $description) {
       // exit(var_dump($_SESSION['user_id']));
        if ($_SESSION['logged'] != TRUE) {
            header('Location: index.php?page=user&action=login');
        } else {
            $connection = new mysqli('localhost', 'root', '');
            
            //check db connection
            if (mysqli_connect_errno($connection)) {
                printf("Connection failed", mysqli_connect_error());
                exit;
            }

            $db = mysqli_select_db($connection, 'blog') or die('Error in database');

            $this->id;
            $this->created;
            $this->userId;

            $this->title = $title;
            $this->description = $description;
       
            
            $query = mysqli_query($connection, 'UPDATE posts
                                                SET title = "' . $title . '",  description = "' . $description . '"
                                                WHERE id = ' . $this->id);

            if (!$query) {
                return false;
            } else {
                return $this;
            }
        }
        mysqli_close($connection);
    }

    //CRUD 
    //Read posts
   
    public static function getPosts($userId) {
        if ($_SESSION['logged'] != TRUE) {
            header('Location: index.php?page=user&action=login'); //header();
        } else {
//        $_SESSION['user_id'] = $userId;
//        
            $connection = new mysqli('localhost', 'root', '');
            //check db connection
            if (mysqli_connect_errno($connection)) {
                printf("Connection failed", mysqli_connect_error());
                exit;
            }
            //exit(var_dump($userId));
            if (empty($userId)) {
                echo 'Please try again';
                return;
            }

            $userId = trim($userId);
            $userId = (int) $userId;

            $db = mysqli_select_db($connection, 'blog') or die('Error in database');
            $arr = array();

            $query = mysqli_query($connection, "SELECT * FROM posts WHERE userId = $userId");

            while ($row = $query->fetch_object()) {
                //  $post = new Post();
//             $row->id;
//             $row->title;
//             $row->description;
//             $row->created;
//             $row->userId;
//            
                array_push($arr, $row);
            }

            mysqli_close($connection);
            return $arr;
        }
    }
    
    //Create posts
    public static function createPost($title, $description) {
        //exit(var_dump($_SESSION));
        if ($_SESSION['logged'] != TRUE) {
            //exit(var_dump($_SESSION));
           header('Location: index.php?page=user&action=login');
            //exit;
        } else {
           //exit(var_dump($_SESSION));
//        if ($_SESSION['loggin'] != TRUE) {
//            return $errors[] = 'Error';
//        }
//        $connection
            //$userId = 1;  
            //exit(var_dump($_SESSION['user_id']));
            
            $connection = new mysqli('localhost', 'root', '');
            //check db connection
            if (mysqli_connect_errno($connection)) {
                printf("Connection failed", mysqli_connect_error());
                exit;
            }

            $db = mysqli_select_db($connection, 'blog') or die('Error in database');

            $title = mysqli_real_escape_string($connection, $title);
            $description = mysqli_real_escape_string($connection, $description);
            //$created = mysqli_real_escape_string($connection, $created);
            //  $userId = (int)$userId;

            $errors = array();
            //TODO - validation and mysql_real_escape_string 

            if (empty($title)) {
                $errors[] = '<p class="error">Title is required</p>';
            } else {
                $title = $_POST['title'];
            }

            if (empty($description)) {
                $errors[] = '<p class="error">>Description is required</p>';
            } else {
                $description = $_POST['description'];
            }

//        if (empty($userId)) {
//            $errors[] = '<p class="error">User id is required</p>';
//        } else {
//            $userId = $_POST['userId'];
//        }

            if (count($errors) > 0) {
                //exit(var_dump($errors));
                return $errors;
            }

            $post = new Post();
            $post->title = $title;
            $post->description = $description;
            //$post->created = $created;
            $post->userId = $_SESSION['user_id'];

            $query = mysqli_query($connection, 'INSERT INTO posts (title, description, userId) VALUES("' . $title . '", "' . $description . '", "' . $_SESSION['user_id'] . '")');

            if (!$query) {
                //exit(var_dump($query));
                return $errors[] = 'Database Errors';
            } else {
                return $post;
            }
            mysqli_close($connection);
        }
    }

    //DeletePost
    public function deletePost(){
        
        $connection = new mysqli('localhost', 'root', '');
        //check db connection
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed", mysqli_connect_error());
            exit;
        }
        
        $db = mysqli_select_db($connection, 'blog') or die('Error in database');
        $errors = array();
        
        $query = mysqli_query( $connection, "DELETE FROM posts WHERE id = $this->id");//post->id = this->id
        //echo $_SESSION['user_id'];
        if (!$query) {
            $errors[] = 'Error query';
        }
        
        if (count($errors) > 0) {
            return false;
        }else{
            mysqli_close($connection);
            return true;
        }
      
    }
}
