<?php
class User {

    private $id;
    public  $name,
            $email,
            $password,
            $roleId = 1;//author

    public static function registerUser($name, $email, $password, $confirmPassword) {
        // exit(var_dump('dfdas'));
        $connection = mysqli_connect('localhost', 'root', '');
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed", mysqli_connect_error());
            exit;
        }
        $db = mysqli_select_db($connection, 'blog') or die('Error in database');

        //Validation and Normalization 
        $name = htmlentities(trim($name));
        $name = mysqli_real_escape_string($connection, $name);

        $email = htmlentities(trim($email));
        $email = mysqli_real_escape_string($connection, $email);

        $password = htmlentities(trim($password));
        $password = mysqli_real_escape_string($connection, $password);

        $confirmPassword = htmlentities(trim($confirmPassword));
        $confirmPassword = mysqli_real_escape_string($connection, $confirmPassword);
        
        $errors  = array();
        
        if ($password != $confirmPassword) {
            $errors[] = 'Invalid Password';
        }
        
        if (filter_var($email, FILTER_VALIDATE_EMAIL) === false) {
            $errors[] = "$email is a invalid email address";
        } 
        
        if (mb_strlen($name) < 3 && empty($name)) {
             $errors[] =  'Invalid Name';
        }
        if (mb_strlen($password) < 5 && empty($password)) {
            $errors[] =  'Invalid password';
        }
        if (mb_strlen($email) < 3 && empty($email)) {
             $errors[] =  'Invalid Email';
        }
        if (mb_strlen($password) < 5 && empty($confirmPassword)) {
            $errors[] =  'Invalid confirm password';
        }
        
        $password = md5($password);
        
        $query = mysqli_query($connection, 'SELECT id FROM `users` WHERE name = "' . $name . '" OR email = "'.$email.'" LIMIT 1');
        
        if (!$query) {
            //redirect to homepage or register.php
            //header('Location: register.php');
            $errors[] = 'Db error';
        }
        $num_rows = mysqli_num_rows($query);
        if ($num_rows == 1) {
           $errors[] = 'Username or email already exists!. Please try again with another!';
        }
        if (count($errors) > 0) {
            return $errors;
        }

        $user = new User();
        $user->name = $name;
        $user->email = $email;
        $user->password = $password;

        $query = mysqli_query($connection, 'INSERT INTO `users` (name, email, password) VALUES ("' . $name . '", "' . $email . '","' . $password . '")');

        if (!$query) {
            //exit(var_dump($query));
            //redirect to homepage or register.php
            //echo mysqli_error
            $errors[] = 'db error';
            return $errors;
        } else {
            return $user;
        }
        mysqli_close($connection);
    }
    
    public static function loginUser($email, $password) {
        //exit(var_dump($_SESSION));
        //$_SESSION = array();
        $connection = mysqli_connect('localhost', 'root', '');
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed", mysqli_connect_error());
            exit;
        }
        $db = mysqli_select_db($connection, 'blog') or die('Error in database');

        $email = htmlentities(trim($email));
        $email = mysqli_real_escape_string($connection, $email);

        $password = htmlentities(trim($password));
        $password = mysqli_real_escape_string($connection, $password);

        $password = md5($password);
        $errors = array();

        if (empty($email) || empty($password)) {
            $errors[] = 'Invalid email or password!';
        }

        if (count($errors) > 0) {
            return $errors;
        }

        $query = mysqli_query($connection, 'SELECT * FROM `users` WHERE email = "' . $email . '" AND password = "' . $password . '"');

        $row = mysqli_fetch_assoc($query);
        
        //exit(var_dump($row));
        if (!$query) {
            mysqli_error($connection);
        }

        $num_rows = mysqli_num_rows($query);

        if ($num_rows == 1) { // log in
            //exit(var_dump($row));
            $_SESSION['logged'] = true;
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['name'];
           // exit(var_dump($_SESSION['user_id']));
            $_SESSION['email'] = $email;
            //exit(var_dump($_SESSION));
            header('Location: index.php?page=posts&action=get');
        }else {
            header('Location : index.php?page=user&action=login');
           // echo 'Invalid username or password!';
        }
        mysqli_close($connection);
    }

    //user can update password 

    public static function updatePassword($email, $password, $newPassword, $confirmPassword) {
       
        if ($_SESSION['logged'] == FALSE) {
            //exit(var_dump($_SESSION['user_id']));
           header('Location: index.php');
        }
        $connection = mysqli_connect('localhost', 'root', '');
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed", mysqli_connect_error());
            exit;
        }
        $db = mysqli_select_db($connection, 'blog') or die('Error in database');

        //Validation:
        $email = mysqli_real_escape_string($connection, $email);

        $password = mysqli_real_escape_string($connection, $password);
        $password = md5($password);

        $newPassword = mysqli_real_escape_string($connection, $newPassword);
        $newPassword = md5($newPassword);

        $confirmPassword = mysqli_real_escape_string($connection, $confirmPassword);
        $confirmPassword = md5($confirmPassword);

        $errors = array();
        if (empty($email)) {
            $errors[] = '';
        }
        if ($newPassword != $confirmPassword) {
            $errors[] = 'Your passwords do not match.';
        }
        
        if (count($errors) > 0) {
            return $errors;
        }else{
            
            $udpated = new User();
            $updated->email = $email;
            $updated->password = $password;

            $query = mysqli_query($connection, 'UPDATE `users` SET password = "' . $newPassword . '" WHERE  email = "' . $email . '" AND password = "' . $password . '"');
            echo "You have successfully changed your password.";
            return $updated;
           
            mysqli_close($connection);
        }
    }
    
    public static function logoutUser($userId){
        session_destroy();
        header('Location: index.php');
        exit;
    }

}
