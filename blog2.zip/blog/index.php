<?php
$title = 'Blog System';
include './inc/header.php';
include './data/data.php';
include './lib/User.php';
include './lib/Post.php';
include './lib/DispatchRequest.php';
?>
<div class="container">
    <div class="top">
        <div class="logo">
            <a href="index.php">
               <!-- <img class="logo1"src="img/logo.jpg"></img> -->
            </a>
        </div>
        <div class="date" id="txt">
            <?php //=date('Y-m-d H:i:s', time() + 3600); ?>
        </div>
        <div class="menu">
            <ul>
                <?php
                foreach ($menu as $value) {
                    echo '<li><a href="' . $value['link'] . '">' . $value['name'] . '</a></li>';
                }
                ?>
            </ul> 
            <div class="greeting">
                 <a href="index.php?page=user&action=register">Register</a><br/>
                <?php
                if (isset($_SESSION['logged'])) {
                    echo '<span class="session">Hello, ' . $_SESSION['username'] . '!</span>';
                    echo '<br/>';
                    echo '<a href="index.php?page=user&action=logout">Log out</a>';
                } else {
                    echo 'Hello, user!';
                }
                ?>
            </div>
        </div>
    </div>
    <div class="body">
        <?php
        if (isset($_SESSION['logged'])) {
            echo  'Email :'. $_SESSION['email'];
        } else {
            echo '<a href="index.php?page=user&action=login">Log in</a>';
        }?>
        <?php
        if (isset($_GET['page'])) {
            DispatchRequest::proccessRequest($_GET['page'], $_GET['action'], 'function');
        }
        ?>
    </div>
</div>
<?php
include './inc/footer.php';