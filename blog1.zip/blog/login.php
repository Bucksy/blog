<?php
$title = 'Log in';
include './inc/header.php';
include './data/data.php';
include './lib/User.php';
include './lib/Post.php';
?>
<div class="container">
    <div class="top">
        <div class="logo">
            <a href="index.php">
               <!-- <img class="logo1"src="img/logo.jpg"></img> -->
            </a>
        </div>
        <div class="date" id="txt">
            <?php //=date('Y-m-d H:i:s', time() + 3600);  ?>
        </div>
        <div class="menu">
            <ul>
                <?php
                foreach ($menu as $value) {
                    echo '<li><a href="' . $value['link'] . '">' . $value['name'] . '</a></li>';
                }
                ?>
            </ul> 
            <div class="greeting">

            </div>
        </div>
    </div>
    <div class="body">
        <br/>
        <br/> 
        <a href="index.php">Back</a>
        <form action="login.php" method="POST">
            <label for="email">Email: </label>
            <input type="email" name="email" id="emailLogin" value=""/><br/>
            <label for="password">Password: </label>
            <input type="password" name="password" id="password" value=""/><br/>
            <input type="submit" name="submitLogin" value="Login"/>
        </form>
        <?php
        echo '<pre>' . print_r($_POST, true) . '</pre>';
        if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submitLogin'])) {
            if ($_SESSION['logged'] == TRUE) {
                header('Location: ./posts.php');
            }
            $user = User::loginUser($_POST['email'], $_POST['password']);
            if (is_array($user)) {
                foreach ($user as $value) {
                    echo $value . '<br/>';
                }
            }
            //echo $user->name;
            
        }
        ?>
    </div>
</div>
<?php
include './inc/footer.php';
