<?php
$title = 'Blog System';
include './inc/header.php';
include './data/data.php';
include './lib/User.php';
include './lib/Post.php';

?>
<div class="container">
    <div class="top">
        <div class="logo">
            <a href="index.php">
               <!-- <img class="logo1"src="img/logo.jpg"></img> -->
            </a>
        </div>
        <div class="date" id="txt">
            <?php //=date('Y-m-d H:i:s', time() + 3600); ?>
        </div>
        <div class="menu">
            <ul>
                <?php
                foreach ($menu as $value) {
                    echo '<li><a href="' . $value['link'] . '">' . $value['name'] . '</a></li>';
                }
                ?>
            </ul> 
            <div class="greeting">

            </div>
        </div>
    </div>
    <div class="body">
        <a href="update.php">Update Post</a>
        <a href="create.php">Create Post</a>
        <a href="register.php">Register</a>
        <a href="login.php">Log in</a>
        <br/>

       

    </div>
</div>

<?php
include './inc/footer.php';

