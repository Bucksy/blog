$(document).ready(function(){
   // console.log('jquery loaded');
   
   function disableRegister(){
       $('#registerButton').prop('disabled', 'disabled');
   }
   
   function enableRegister(){
       $('#registerButton').removeProp('disabled');
   }
   
   function errorOnFieldId(id){
       $(id).prop('style', 'border:1px solid red');
   }
   
   function successOnField(id){
       $(id).prop('style', 'border:1px solid green');
   }
   $('#confirmPassword').on('input',function(){
       //console.log('password change');
       var password = $('#password').val(); // value of password
       var confirmPassword = $('#confirmPassword').val();
       
        if (password != confirmPassword) {
            errorOnFieldId('#confirmPassword');
            disableRegister();
        }else{
            successOnField('#confirmPassword');
            enableRegister();
        }
   });
   
   //email validation
    $('#email').on('input',function(){
       // ^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$.
        var email = $('#email').val();
        var emailRegex = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var isValid = emailRegex.test(email);//true or false 
       // console.log(match);
        if (!isValid) {
            disableRegister();
            errorOnFieldId('#email');
        }else{
            enableRegister();
            successOnField('#email');
        }
    });
    
});
