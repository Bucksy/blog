<?php
include './lib/Post.php';
?>
<form action="update.php" method="POST">
<input type="text" name="postId" id="title" value=""/><br/>
<label for="title">Title: </label>
<input type="text" name="title" id="title" value=""/><br/>
<label for="description">Description: </label>
<input type="description" name="description" id="decription" value=""/><br/>
<input type="submit" name="updatePost" value="Update"/>
</form>


<?php 
include './posts/updatePost.php';
include './inc/footer.php';