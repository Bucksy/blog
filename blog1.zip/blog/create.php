<?php include './lib/Post.php'; ?>
<form action="create.php" method="POST">
    <label for="id">Title: </label>
    <input type="text" name="title" id="title" value=""/><br/>
    <label for="description">Description: </label>
    <input type="description" name="description" id="decription" value=""/><br/>
    <input type="submit" name="createPost" value="Create"/>
</form>

<?php include './posts/createPost.php'; ?>