<?php
// $userPost = Post::getPosts(1);
// echo $userPost[0]->title;
//echo '<pre>' . print_r($userPost, true) . '</pre>'; 
// $result = Post::createPost($_POST['title'], $_POST['description'], $_POST['created'],$_POST['userId']);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['createPost'])) {
    $result = Post::createPost($_POST['title'], $_POST['description'], $_POST['created']); //object
    if (is_array($result)) {
        foreach ($result as $value) {
            echo $value;
        }
    } else {
        echo 'Created Post: ', $result->title;
    }
}
echo '<pre>' . print_r($_POST, true) . '</pre>';
