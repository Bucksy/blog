<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['updatePost'])) {
    $postId = $_POST['postId'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    
    $post = Post::getPost($postId);
    $updatedPost = $post->updatePost($title, $description);
}
echo '<pre>' . print_r($_POST, true) . '</pre>';
