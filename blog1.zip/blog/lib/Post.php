<?php

class Post {
    
    private $id;
    public $title,
           $description,
           $created,
           $userId;
    
    //Get Post - Get the data from database 
    public static function getPost($idPost){
         $connection = new mysqli('localhost', 'root', '');
        //check db connection
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed",mysqli_connect_error());
            exit;
        }
        
        if (empty($idPost)) {
            echo 'Please try again';
            return;
        }
        
        $idPost = (int)$idPost;
        $db = mysqli_select_db( $connection, 'blog') or die('Error in database');
        
        $query = mysqli_query($connection, 'SELECT * FROM posts WHERE id = "'.$idPost.'"');
        $row = $query->fetch_assoc();
        
        $post = new Post();
        $post->id = $row['id'];
        $post->title = $row['title'];
        $post->description = $row['description'];
        $post->created = $row['created'];
        $post->userId = $row['userId'];
        
        return $post;
    }
    
    public function updatePost($title, $description){
          $connection = new mysqli('localhost', 'root', '');
        //check db connection
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed",mysqli_connect_error());
            exit;
        }
        
//        if (empty($userId)) {
//            echo 'Please try again';
//            return;
//        }
        
        $db = mysqli_select_db( $connection, 'blog') or die('Error in database');
        
        $this->id;
        $this->created;
        $this->userId;
        
        $this->title = $title;
        $this->description = $description;
        
         $query = mysqli_query($connection, 'UPDATE posts
                                SET title = "'.$title.'",  description = "' . $description . '"
                                WHERE id = '.$this->id);
        
        if($query){
            return $this;
        }else{
           return;
        }
        
        mysqli_close($connection);
        
    }
       //CRUD 
    //Read posts
   
    public static function getPosts($userId){
//         if ($_SESSION['logged'] != TRUE) {
//            return $errors[] = 'Error';
//        }
//        
//        $_SESSION['user_id'] = $userId;
//        
         $connection = new mysqli('localhost', 'root', '');
        //check db connection
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed",mysqli_connect_error());
            exit;
        }
        //exit(var_dump($userId));
        if (empty($userId)) {
            echo 'Please try again';
            return;
        }
        
        $userId = trim($userId);
        $userId = (int)$userId;
        
        $db = mysqli_select_db( $connection, 'blog') or die('Error in database');
        $arr = array();
        
        $query = mysqli_query($connection, "SELECT * FROM posts WHERE userid = $userId");
        
        while ($row = $query->fetch_assoc()) {
            $post = new Post();
            
            $post->id = $row['id'];
            $post->title = $row['title'];
            $post->description = $row['description'];
            $post->created = $row['created'];
            $post->userId = $row['userId'];
            
            array_push($arr, $post);
        }
       
        mysqli_close($connection);
        return $arr; 
    }
    //Create posts
    public static function createPost($title, $description, $created){
        
//        if ($_SESSION['loggin'] != TRUE) {
//            return $errors[] = 'Error';
//        }
//        $connection
        $userId = 1;  
        $connection = new mysqli('localhost', 'root', '');
        //check db connection
        if (mysqli_connect_errno($connection)) {
            printf("Connection failed", mysqli_connect_error());
            exit;
        }
        
        $db = mysqli_select_db($connection, 'blog') or die('Error in database');
        $title = mysqli_real_escape_string($connection, $title);
        $description = mysqli_real_escape_string($connection,$description);
        $created = mysqli_real_escape_string($connection, $created);
        $userId = (int) $userId;

        $errors = array();
        //TODO - validation and mysql_real_escape_string 

        if (empty($title)) {
            $errors[] = '<p class="error">Title is required</p>';
        } else {
            $title = $_POST['title'];
        }

        if (empty($description)) {
            $errors[] = '<p class="error">>Description is required</p>';
        } else {
            $description = $_POST['description'];
        }



        if (empty($userId)) {
            $errors[] = '<p class="error">User id is required</p>';
        } else {
            $userId = $_POST['userId'];
        }

        if (count($errors) > 0) {
            //exit(var_dump($errors));
            return $errors;
        }

        $post = new Post();
        $post->title = $title;
        $post->description = $description;
        $post->created = $created;
        $post->userId = $userId;
        
        $query = mysqli_query($connection, 'INSERT INTO posts (title, description, userId) VALUES("'.$title.'", "'.$description.'", "'.$userId.'")');
//        
//        $query = sprintf('INSERT INTO posts(title, description, created, userId)
//                VALUES("%s", "%s", "%s", "%s")', 
//                      $title,$description, $created, $userId);
        
        if (!$query) {
            exit(var_dump($query));
            return $errors[] = 'Database Errors';
        }else{
            return $post;
        }
         mysqli_close($connection);
    }
    
    //Update Post
    
    //DeletePost
    
}
