<?php

$menu = array(
     0 => array(
         'name' =>'Home',
         'link' => 'index.php'),
    1 => array(
        'name' => 'Blog Page',
        'link' => 'blog.php'
        ),
    2 => array(
        'name' => 'About',
        'link' => 'about.php'
    )
);

