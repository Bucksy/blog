<?php
$title = 'Registration';
include './inc/header.php';
include './data/data.php';
include './lib/User.php';
include './lib/Post.php';
?>
<div class="container">
    <div class="top">
        <div class="logo">
            <a href="index.php">
               <!-- <img class="logo1"src="img/logo.jpg"></img> -->
            </a>
        </div>
        <div class="date" id="txt">
            <?php //=date('Y-m-d H:i:s', time() + 3600);  ?>
        </div>
        <div class="menu">
            <ul>
                <?php
                foreach ($menu as $value) {
                    echo '<li><a href="' . $value['link'] . '">' . $value['name'] . '</a></li>';
                }
                ?>
            </ul> 
            <div class="greeting">

            </div>
        </div>
    </div>
    <div class="body">
        <form action="register.php" method="POST">
            Username:  
            <input type="text" name="name" id="name" value=""/><br/>
            Email:  
            <input type="text" name="email" id="email" value=""/><br/>
            Password:
            <input type="password" name="password" id="password" value=""/><br/>
            Confirm Password: 
            <input type="password" name="confirmPassword" id="confirmPassword" value=""/><br/>

            <input type="submit" name="register" id="registerButton" value="Register"/>
        </form>
        <?php
         if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
            $user = User::registerUser($_POST['name'], $_POST['email'], $_POST['password'], $_POST['confirmPassword']);
            if(is_array($user)) {
                foreach ($user as $value) {
                    echo $value . '<br/>';
                }
            }else{
                 //$user = User::registerUser($_POST['name'], $_POST['email'], $_POST['password'], $_POST['confirmPassword']);
                echo $user->name . ' is successfully registered';
                // header('Location: ');
            }
        }
?>
 </div>
</div>
<?php
include './inc/footer.php';
